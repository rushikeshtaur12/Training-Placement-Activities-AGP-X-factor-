
    <html class="supernova">

    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="">
        <title>Registration Form</title>

        <link type="text/css" media="print" rel="stylesheet" href="https://cdn.jotfor.ms/css/printForm.css?3.3.26019">
        <link type="text/css" rel="stylesheet" href="https://cdn.jotfor.ms/themes/CSS/5e6b428acc8c4e222d1beb91.css?themeRevisionID=5eb3b4ae85bd2e1e2966db96 /">
        <link type="text/css" rel="stylesheet" href="https://cdn.jotfor.ms/css/styles/payment/payment_styles.css?3.3.26019 /">
        <link type="text/css" rel="stylesheet" href="https://cdn.jotfor.ms/css/styles/payment/payment_feature.css?3.3.26019 /">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="assets/css/chartist.min.css" rel="stylesheet" media="screen">
        <link href="assets/css/owl.carousel.min.css" rel="stylesheet" media="screen">
        <link href="assets/css/owl.theme.default.min.css" rel="stylesheet" media="screen">
        <link href="assets/css/style.css" rel="stylesheet" media="screen">
        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
        <link href="assets/fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet" media="screen">



        <script src="https://cdnjs.cloudflare.com/ajax/libs/punycode/1.4.1/punycode.min.js"></script>
        <script src="https://cdn.jotfor.ms/js/vendor/jquery-1.8.0.min.js?v=3.3.26019" type="text/javascript"></script>
        <script src="https://cdn.jotfor.ms/js/vendor/maskedinput.min.js?v=3.3.26019" type="text/javascript"></script>
        <script src="https://cdn.jotfor.ms/js/vendor/jquery.maskedinput.min.js?v=3.3.26019" type="text/javascript"></script>
        <script src="https://cdn.jotfor.ms/static/prototype.forms.js" type="text/javascript"></script>
        <script src="https://cdn.jotfor.ms/static/jotform.forms.js?3.3.26019" type="text/javascript"></script>
        <script type="text/javascript">
            JotForm.init(function() {
                setTimeout(function() {
                    $('input_6').hint('ex: myname@example.com');
                }, 20);
                JotForm.setPhoneMaskingValidator('input_27_full', '(##) ### ### ####');
                if (window.JotForm && JotForm.accessible) $('input_53').setAttribute('tabindex', 0);
                if (window.JotForm && JotForm.accessible) $('input_54').setAttribute('tabindex', 0);
                if (window.JotForm && JotForm.accessible) $('input_55').setAttribute('tabindex', 0);
                if (window.JotForm && JotForm.accessible) $('input_56').setAttribute('tabindex', 0);
                if (window.JotForm && JotForm.accessible) $('input_58').setAttribute('tabindex', 0);
                JotForm.setCustomHint('input_58', 'Type here...');
                if (window.JotForm && JotForm.accessible) $('input_59').setAttribute('tabindex', 0);
                JotForm.setCustomHint('input_59', 'Type here...');
                JotForm.newDefaultTheme = true;
                JotForm.extendsNewTheme = false;
                JotForm.newPaymentUIForNewCreatedForms = false;
                JotForm.newPaymentUI = true;
                /*INIT-END*/
            });

            JotForm.prepareCalculationsOnTheFly([null, {
                "name": "clickTo",
                "qid": "1",
                "text": "Student Registration Form",
                "type": "control_head"
            }, null, {
                "name": "gender",
                "qid": "3",
                "text": "Gender",
                "type": "control_dropdown"
            }, {
                "name": "studentName",
                "qid": "4",
                "text": "Student Name",
                "type": "control_fullname"
            }, null, {
                "name": "studentEmail6",
                "qid": "6",
                "subLabel": "example@example.com",
                "text": "Student E-mail",
                "type": "control_email"
            }, null, null, null, null, null, null, null, null, null, null, null, null, {
                "name": "submit",
                "qid": "19",
                "text": "Clear Fields",
                "type": "control_button"
            }, {
                "name": "submit20",
                "qid": "20",
                "text": "Submit Application",
                "type": "control_button"
            }, null, null, {
                "name": "address",
                "qid": "23",
                "text": "Address",
                "type": "control_address"
            }, {
                "name": "birthDate24",
                "qid": "24",
                "text": "Birth Date",
                "type": "control_birthdate"
            }, null, {
                "name": "workNumber",
                "qid": "26",
                "text": "Work Number",
                "type": "control_phone"
            }, {
                "name": "mobileNumber",
                "qid": "27",
                "text": "Mobile Number",
                "type": "control_phone"
            }, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, {
                "name": "courses",
                "qid": "46",
                "text": "Courses",
                "type": "control_dropdown"
            }, {
                "description": "",
                "name": "academicYear",
                "qid": "47",
                "subLabel": "",
                "text": "Academic Year ",
                "type": "control_dropdown"
            }, null, null, null, null, {
                "name": "percentage",
                "qid": "52",
                "text": "Percentage: ",
                "type": "control_head"
            }, {
                "description": "",
                "name": "1stYear",
                "qid": "53",
                "subLabel": "",
                "text": "1st Year :",
                "type": "control_textbox"
            }, {
                "description": "",
                "name": "2ndYear",
                "qid": "54",
                "subLabel": "",
                "text": "2nd Year :",
                "type": "control_textbox"
            }, {
                "description": "",
                "name": "3rdYear",
                "qid": "55",
                "subLabel": "",
                "text": "3rd Year :",
                "type": "control_textbox"
            }, {
                "description": "",
                "name": "4thYear",
                "qid": "56",
                "subLabel": "",
                "text": "4th Year :",
                "type": "control_textbox"
            }, null, {
                "description": "",
                "name": "certificates",
                "qid": "58",
                "subLabel": "",
                "text": "Certificates :",
                "type": "control_textarea"
            }, {
                "description": "",
                "name": "training",
                "qid": "59",
                "subLabel": "",
                "text": "Training :",
                "type": "control_textarea"
            }]);
            setTimeout(function() {
                JotForm.paymentExtrasOnTheFly([null, {
                    "name": "clickTo",
                    "qid": "1",
                    "text": "Student Registration Form",
                    "type": "control_head"
                }, null, {
                    "name": "gender",
                    "qid": "3",
                    "text": "Gender",
                    "type": "control_dropdown"
                }, {
                    "name": "studentName",
                    "qid": "4",
                    "text": "Student Name",
                    "type": "control_fullname"
                }, null, {
                    "name": "studentEmail6",
                    "qid": "6",
                    "subLabel": "example@example.com",
                    "text": "Student E-mail",
                    "type": "control_email"
                }, null, null, null, null, null, null, null, null, null, null, null, null, {
                    "name": "submit",
                    "qid": "19",
                    "text": "Clear Fields",
                    "type": "control_button"
                }, {
                    "name": "submit20",
                    "qid": "20",
                    "text": "Submit Application",
                    "type": "control_button"
                }, null, null, {
                    "name": "address",
                    "qid": "23",
                    "text": "Address",
                    "type": "control_address"
                }, {
                    "name": "birthDate24",
                    "qid": "24",
                    "text": "Birth Date",
                    "type": "control_birthdate"
                }, null, {
                    "name": "workNumber",
                    "qid": "26",
                    "text": "Work Number",
                    "type": "control_phone"
                }, {
                    "name": "mobileNumber",
                    "qid": "27",
                    "text": "Mobile Number",
                    "type": "control_phone"
                }, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, {
                    "name": "courses",
                    "qid": "46",
                    "text": "Courses",
                    "type": "control_dropdown"
                }, {
                    "description": "",
                    "name": "academicYear",
                    "qid": "47",
                    "subLabel": "",
                    "text": "Academic Year ",
                    "type": "control_dropdown"
                }, null, null, null, null, {
                    "name": "percentage",
                    "qid": "52",
                    "text": "Percentage: ",
                    "type": "control_head"
                }, {
                    "description": "",
                    "name": "1stYear",
                    "qid": "53",
                    "subLabel": "",
                    "text": "1st Year :",
                    "type": "control_textbox"
                }, {
                    "description": "",
                    "name": "2ndYear",
                    "qid": "54",
                    "subLabel": "",
                    "text": "2nd Year :",
                    "type": "control_textbox"
                }, {
                    "description": "",
                    "name": "3rdYear",
                    "qid": "55",
                    "subLabel": "",
                    "text": "3rd Year :",
                    "type": "control_textbox"
                }, {
                    "description": "",
                    "name": "4thYear",
                    "qid": "56",
                    "subLabel": "",
                    "text": "4th Year :",
                    "type": "control_textbox"
                }, null, {
                    "description": "",
                    "name": "certificates",
                    "qid": "58",
                    "subLabel": "",
                    "text": "Certificates :",
                    "type": "control_textarea"
                }, {
                    "description": "",
                    "name": "training",
                    "qid": "59",
                    "subLabel": "",
                    "text": "Training :",
                    "type": "control_textarea"
                }]);
            }, 20);
        </script>
    </head>

    <body data-new-gr-c-s-check-loaded="14.1016.0" data-gr-ext-installed="">

        <div class="row dashboard-top-nav">
            <div class="col-sm-3 logo">
                <h5><i class="fa fa-book"></i>AGPIT T&P DASHBOARD</h5>
            </div>

            <div class="col-sm-5 notification-area">
                <ul class="top-nav-list">

                    <li class="user dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span>MEGHA SWAMI<span class="caret"></span></span>
                        </a>
                        <ul class="dropdown-menu notification-list">
                            <li>
                                <a href="#"><i class="fa fa-users"></i> USER PROFILE</a>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-key"></i> CHANGE PASSWORD</a>
                            </li>
                            <li>
                                <div class="all-notifications">
                                    <a href="#">LOGOUT</a>
                                </div>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>

        <div class="parent-wrapper" id="outer-wrapper">
            <!-- SIDE MENU -->
            <div class="sidebar-nav-wrapper" id="sidebar-wrapper">
                <ul class="sidebar-nav">
                    <li>
                        <a href="student-dashboard.html"><i class="fa fa-home menu-icon"></i> HOME</a>
                    </li>

                    <li class="dropdown">
                        <li>
                            <a href="form1.html"><i class="fa fa-caret-right"></i>REGISTRATION</a>
                        </li>
                    </li>
                    <li class="dropdown">
                        <li>
                            <a href="result.html"><i class="fa fa-caret-right"></i>RESULTS</a>
                        </li>
                    </li>
                    <div class="clearfix"></div>
                </ul>
            </div>
            <!--main content-->
            <div class="main-content" id="content-wrapper">
                <form class="jotform-form" action="insert.php" method="post" name="form_211715617695462" id="211715617695462" accept-charset="utf-8" autocomplete="on" novalidate="true">
                    <input type="hidden" name="formID" value="211715617695462">
                    <input type="hidden" id="JWTContainer" value="">
                    <input type="hidden" id="cardinalOrderNumber" value="">
                    <div role="main" class="form-all">
                        <style>
                            .form-all:before {
                                background: none;
                            }
                        </style>
                        <ul class="form-section page-section">
                            <li id="cid_1" class="form-input-wide" data-type="control_head">
                                <div class="form-header-group  header-large">
                                    <div class="header-text httal htvam">
                                        <h1 id="header_1" class="form-header" data-component="header">
                                            Student Registration Form
                                        </h1>
                                        <div id="subHeader_1" class="form-subHeader">
                                            Fill out the form carefully for registration
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="form-line jf-required" data-type="control_fullname" id="id_4">
                                <label class="form-label form-label-top form-label-extended form-label-auto" id="label_4" for="first_4">
          Student Name
          <span class="form-required">
            *
          </span>
        </label>
                                <div id="cid_4" class="form-input-wide jf-required" data-layout="full">
                                    <div data-wrapper-react="true" class="extended">
                                        <span class="form-sub-label-container" style="vertical-align:top" data-input-type="first">
              <input type="text" id="first_4" name="q4_studentNamefirst" class="form-textbox validate[required]" size="10" value="" data-component="first" aria-labelledby="label_4 sublabel_4_first" required="">
              <label class="form-sub-label" for="first_4" id="sublabel_4_first" style="min-height:13px" aria-hidden="false"> First Name </label>
            </span>
                                        <span class="form-sub-label-container" style="vertical-align:top" data-input-type="middle">
              <input type="text" id="middle_4" name="q4_studentNamemiddle" class="form-textbox" size="10" value="" data-component="middle" aria-labelledby="label_4 sublabel_4_middle" required="">
              <label class="form-sub-label" for="middle_4" id="sublabel_4_middle" style="min-height:13px" aria-hidden="false"> Middle Name </label>
            </span>
                                        <span class="form-sub-label-container" style="vertical-align:top" data-input-type="last">
              <input type="text" id="last_4" name="q4_studentNamelast" class="form-textbox validate[required]" size="15" value="" data-component="last" aria-labelledby="label_4 sublabel_4_last" required="">
              <label class="form-sub-label" for="last_4" id="sublabel_4_last" style="min-height:13px" aria-hidden="false"> Last Name </label>
            </span>
                                    </div>
                                </div>
                            </li>
                            <li class="form-line jf-required" data-type="control_email" id="id_6">
                                <label class="form-label form-label-top" id="label_6" for="input_6">
          Student E-mail
          <span class="form-required">
            *
          </span>
        </label>
                                <div id="cid_6" class="form-input-wide jf-required" data-layout="half">
                                    <span class="form-sub-label-container" style="vertical-align:top">
            <input type="email" id="input_6" name="q6_studentEmail6" class="form-textbox validate[required, Email]" style="width:310px" size="310" value="" placeholder="ex: myname@example.com" data-component="email" aria-labelledby="label_6 sublabel_input_6" required="">
            <label class="form-sub-label" for="input_6" id="sublabel_input_6" style="min-height:13px" aria-hidden="false"> example@example.com </label>
          </span>
                                </div>
                            </li>
                            <li class="form-line form-line-column form-col-1 jf-required" data-type="control_birthdate" id="id_24">
                                <label class="form-label form-label-top" id="label_24" for="input_24">
          Birth Date
          <span class="form-required">
            *
          </span>
        </label>
                                <div id="cid_24" class="form-input-wide jf-required" data-layout="full">
                                    <div data-wrapper-react="true">
                                        <span class="form-sub-label-container" style="vertical-align:top">
              <select name="q24_birthDate24month" id="input_24_month" class="form-dropdown validate[required]" data-component="birthdate-month" aria-labelledby="label_24 sublabel_24_month">
                <option>  </option>
                <option value="January"> January </option>
                <option value="February"> February </option>
                <option value="March"> March </option>
                <option value="April"> April </option>
                <option value="May"> May </option>
                <option value="June"> June </option>
                <option value="July"> July </option>
                <option value="August"> August </option>
                <option value="September"> September </option>
                <option value="October"> October </option>
                <option value="November"> November </option>
                <option value="December"> December </option>
              </select>
              <label class="form-sub-label" for="input_24_month" id="sublabel_24_month" style="min-height:13px" aria-hidden="false"> Month </label>
            </span>
                                        <span class="form-sub-label-container" style="vertical-align:top">
              <select name="q24_birthDate24day" id="input_24_day" class="form-dropdown validate[required]" data-component="birthdate-day" aria-labelledby="label_24 sublabel_24_day">
                <option>  </option>
                <option value="1"> 1 </option>
                <option value="2"> 2 </option>
                <option value="3"> 3 </option>
                <option value="4"> 4 </option>
                <option value="5"> 5 </option>
                <option value="6"> 6 </option>
                <option value="7"> 7 </option>
                <option value="8"> 8 </option>
                <option value="9"> 9 </option>
                <option value="10"> 10 </option>
                <option value="11"> 11 </option>
                <option value="12"> 12 </option>
                <option value="13"> 13 </option>
                <option value="14"> 14 </option>
                <option value="15"> 15 </option>
                <option value="16"> 16 </option>
                <option value="17"> 17 </option>
                <option value="18"> 18 </option>
                <option value="19"> 19 </option>
                <option value="20"> 20 </option>
                <option value="21"> 21 </option>
                <option value="22"> 22 </option>
                <option value="23"> 23 </option>
                <option value="24"> 24 </option>
                <option value="25"> 25 </option>
                <option value="26"> 26 </option>
                <option value="27"> 27 </option>
                <option value="28"> 28 </option>
                <option value="29"> 29 </option>
                <option value="30"> 30 </option>
                <option value="31"> 31 </option>
              </select>
              <label class="form-sub-label" for="input_24_day" id="sublabel_24_day" style="min-height:13px" aria-hidden="false"> Day </label>
            </span>
                                        <span class="form-sub-label-container" style="vertical-align:top">
              <select name="q24_birthDate24year" id="input_24_year" class="form-dropdown validate[required]" data-component="birthdate-year" aria-labelledby="label_24 sublabel_24_year">
                <option>  </option>
                <option value="2021"> 2021 </option>
                <option value="2020"> 2020 </option>
                <option value="2019"> 2019 </option>
                <option value="2018"> 2018 </option>
                <option value="2017"> 2017 </option>
                <option value="2016"> 2016 </option>
                <option value="2015"> 2015 </option>
                <option value="2014"> 2014 </option>
                <option value="2013"> 2013 </option>
                <option value="2012"> 2012 </option>
                <option value="2011"> 2011 </option>
                <option value="2010"> 2010 </option>
                <option value="2009"> 2009 </option>
                <option value="2008"> 2008 </option>
                <option value="2007"> 2007 </option>
                <option value="2006"> 2006 </option>
                <option value="2005"> 2005 </option>
                <option value="2004"> 2004 </option>
                <option value="2003"> 2003 </option>
                <option value="2002"> 2002 </option>
                <option value="2001"> 2001 </option>
                <option value="2000"> 2000 </option>
                <option value="1999"> 1999 </option>
                <option value="1998"> 1998 </option>
                <option value="1997"> 1997 </option>
                <option value="1996"> 1996 </option>
                <option value="1995"> 1995 </option>
                <option value="1994"> 1994 </option>
                <option value="1993"> 1993 </option>
                <option value="1992"> 1992 </option>
                <option value="1991"> 1991 </option>
                <option value="1990"> 1990 </option>
                <option value="1989"> 1989 </option>
                <option value="1988"> 1988 </option>
                <option value="1987"> 1987 </option>
                <option value="1986"> 1986 </option>
                <option value="1985"> 1985 </option>
                <option value="1984"> 1984 </option>
                <option value="1983"> 1983 </option>
                <option value="1982"> 1982 </option>
                <option value="1981"> 1981 </option>
                <option value="1980"> 1980 </option>
                <option value="1979"> 1979 </option>
                <option value="1978"> 1978 </option>
                <option value="1977"> 1977 </option>
                <option value="1976"> 1976 </option>
                <option value="1975"> 1975 </option>
                <option value="1974"> 1974 </option>
                <option value="1973"> 1973 </option>
                <option value="1972"> 1972 </option>
                <option value="1971"> 1971 </option>
                <option value="1970"> 1970 </option>
                <option value="1969"> 1969 </option>
                <option value="1968"> 1968 </option>
                <option value="1967"> 1967 </option>
                <option value="1966"> 1966 </option>
                <option value="1965"> 1965 </option>
                <option value="1964"> 1964 </option>
                <option value="1963"> 1963 </option>
                <option value="1962"> 1962 </option>
                <option value="1961"> 1961 </option>
                <option value="1960"> 1960 </option>
                <option value="1959"> 1959 </option>
                <option value="1958"> 1958 </option>
                <option value="1957"> 1957 </option>
                <option value="1956"> 1956 </option>
                <option value="1955"> 1955 </option>
                <option value="1954"> 1954 </option>
                <option value="1953"> 1953 </option>
                <option value="1952"> 1952 </option>
                <option value="1951"> 1951 </option>
                <option value="1950"> 1950 </option>
                <option value="1949"> 1949 </option>
                <option value="1948"> 1948 </option>
                <option value="1947"> 1947 </option>
                <option value="1946"> 1946 </option>
                <option value="1945"> 1945 </option>
                <option value="1944"> 1944 </option>
                <option value="1943"> 1943 </option>
                <option value="1942"> 1942 </option>
                <option value="1941"> 1941 </option>
                <option value="1940"> 1940 </option>
                <option value="1939"> 1939 </option>
                <option value="1938"> 1938 </option>
                <option value="1937"> 1937 </option>
                <option value="1936"> 1936 </option>
                <option value="1935"> 1935 </option>
                <option value="1934"> 1934 </option>
                <option value="1933"> 1933 </option>
                <option value="1932"> 1932 </option>
                <option value="1931"> 1931 </option>
                <option value="1930"> 1930 </option>
                <option value="1929"> 1929 </option>
                <option value="1928"> 1928 </option>
                <option value="1927"> 1927 </option>
                <option value="1926"> 1926 </option>
                <option value="1925"> 1925 </option>
                <option value="1924"> 1924 </option>
                <option value="1923"> 1923 </option>
                <option value="1922"> 1922 </option>
                <option value="1921"> 1921 </option>
                <option value="1920"> 1920 </option>
              </select>
              <label class="form-sub-label" for="input_24_year" id="sublabel_24_year" style="min-height:13px" aria-hidden="false"> Year </label>
            </span>
                                    </div>
                                </div>
                            </li>
                            <li class="form-line form-line-column form-col-2 jf-required" data-type="control_dropdown" id="id_3">
                                <label class="form-label form-label-top" id="label_3" for="input_3">
          Gender
          <span class="form-required">
            *
          </span>
        </label>
                                <div id="cid_3" class="form-input-wide jf-required" data-layout="half">
                                    <select class="form-dropdown validate[required]" id="input_3" name="q3_gender" style="width:310px" data-component="dropdown" required="">
            <option value=""> Please Select </option>
            <option value="Male"> Male </option>
            <option value="Female"> Female </option>
            <option value="N/A"> N/A </option>
          </select>
                                </div>
                            </li>
                            <li class="form-line form-line-column form-col-3 jf-required" data-type="control_phone" id="id_27">
                                <label class="form-label form-label-top" id="label_27" for="input_27_full">
          Mobile Number
          <span class="form-required">
            *
          </span>
        </label>
                                <div id="cid_27" class="form-input-wide jf-required" data-layout="half">
                                    <span class="form-sub-label-container" style="vertical-align:top">
            <input type="tel" id="input_27_full" name="q27_mobileNumberfull" data-type="mask-number" class="mask-phone-number form-textbox validate[required, Fill Mask]" style="width:310px" data-masked="true" value="" placeholder="(00) 000 000 0000" data-component="phone" aria-labelledby="label_27" required="" im-insert="true" maskvalue="(##) ### ### ####">
            <label class="form-sub-label is-empty" for="input_27_full" id="sublabel_27_masked" style="min-height:13px" aria-hidden="false">  </label>
          </span>
                                </div>
                            </li>
                            <li class="form-line form-line-column form-col-5 jf-required" data-type="control_dropdown" id="id_47">
                                <label class="form-label form-label-top form-label-auto" id="label_47" for="input_47">
          Academic Year
          <span class="form-required">
            *
          </span>
        </label>
                                <div id="cid_47" class="form-input-wide jf-required" data-layout="half">
                                    <select class="form-dropdown validate[required]" id="input_47" name="q47_academicYear" style="width:310px" data-component="dropdown" required="">
            <option value=""> Please Select </option>
            <option value="2021-2020"> 2021-2020 </option>
            <option value="2020-2019"> 2020-2019 </option>
            <option value="2019-2018"> 2019-2018 </option>
            <option value="2018-2017"> 2018-2017 </option>
            <option value="2017-2016"> 2017-2016 </option>
          </select>
                                </div>
                            </li>
                            <li class="form-line form-line-column form-col-6 jf-required" data-type="control_dropdown" id="id_46">
                                <label class="form-label form-label-top form-label-auto" id="label_46" for="input_46">
          Courses
          <span class="form-required">
            *
          </span>
        </label>
                                <div id="cid_46" class="form-input-wide jf-required" data-layout="half">
                                    <select class="form-dropdown validate[required]" id="input_46" name="q46_courses" style="width:278px" data-component="dropdown" required="">
            <option value=""> Please Select </option>
            <option value="Computer Engineering"> Computer Engineering </option>
            <option value="Civil Engineering"> Civil Engineering </option>
            <option value="Electronics &amp; Telecommunication"> Electronics &amp; Telecommunication </option>
            <option value="Mechanical Engineering"> Mechanical Engineering </option>
          </select>
                                </div>
                            </li>
                            <li class="form-line" data-type="control_address" id="id_23">
                                <label class="form-label form-label-top form-label-auto" id="label_23" for="input_23_addr_line1"> Address </label>
                                <div id="cid_23" class="form-input-wide" data-layout="full">
                                    <textarea id="input_23_addr_line1" class="form-textarea custom-hint-group form-custom-hint" name="q23_address" style="width:648px;height:163px" data-component="textarea" aria-labelledby="input_23_addr_line1" data-customhint="Type here..." customhinted="true"
                                        placeholder="Type here..." spellcheck="false"></textarea>
                                </div>
                            </li>
                            <li id="cid_52" class="form-input-wide" data-type="control_head">
                                <div class="form-header-group  header-small">
                                    <div class="header-text httal htvam">
                                        <h3 id="header_52" class="form-header" data-component="header">
                                            Percentage:
                                        </h3>
                                    </div>
                                </div>
                            </li>
                            <li class="form-line form-line-column form-col-1" data-type="control_textbox" id="id_53">
                                <label class="form-label form-label-top form-label-auto" id="label_53" for="input_53"> 1st Year : </label>
                                <div id="cid_53" class="form-input-wide" data-layout="half">
                                    <input type="text" id="input_53" name="q53_1stYear" data-type="input-textbox" class="form-textbox" style="width:310px" size="310" value="" data-component="textbox" aria-labelledby="label_53">
                                </div>
                            </li>
                            <li class="form-line form-line-column form-col-2" data-type="control_textbox" id="id_54">
                                <label class="form-label form-label-top form-label-auto" id="label_54" for="input_54"> 2nd Year : </label>
                                <div id="cid_54" class="form-input-wide" data-layout="half">
                                    <input type="text" id="input_54" name="q54_2ndYear" data-type="input-textbox" class="form-textbox" style="width:310px" size="310" value="" data-component="textbox" aria-labelledby="label_54">
                                </div>
                            </li>
                            <li class="form-line form-line-column form-col-3" data-type="control_textbox" id="id_55">
                                <label class="form-label form-label-top form-label-auto" id="label_55" for="input_55"> 3rd Year : </label>
                                <div id="cid_55" class="form-input-wide" data-layout="half">
                                    <input type="text" id="input_55" name="q55_3rdYear" data-type="input-textbox" class="form-textbox" style="width:310px" size="310" value="" data-component="textbox" aria-labelledby="label_55">
                                </div>
                            </li>
                            <li class="form-line form-line-column form-col-4" data-type="control_textbox" id="id_56">
                                <label class="form-label form-label-top form-label-auto" id="label_56" for="input_56"> 4th Year : </label>
                                <div id="cid_56" class="form-input-wide" data-layout="half">
                                    <input type="text" id="input_56" name="q56_4thYear" data-type="input-textbox" class="form-textbox" style="width:310px" size="310" value="" data-component="textbox" aria-labelledby="label_56">
                                </div>
                            </li>
                            <li class="form-line" data-type="control_textarea" id="id_58">
                                <label class="form-label form-label-top form-label-auto" id="label_58" for="input_58"> Certificates : </label>
                                <div id="cid_58" class="form-input-wide" data-layout="full">
                                    <textarea id="input_58" class="form-textarea custom-hint-group form-custom-hint" name="q58_certificates" style="width:648px;height:163px" data-component="textarea" aria-labelledby="label_58" data-customhint="Type here..." customhinted="true" placeholder="Type here..."
                                        spellcheck="false"></textarea>
                                </div>
                            </li>
                            <li class="form-line" data-type="control_textarea" id="id_59">
                                <label class="form-label form-label-top form-label-auto" id="label_59" for="input_59"> Training : </label>
                                <div id="cid_59" class="form-input-wide" data-layout="full">
                                    <textarea id="input_59" class="form-textarea custom-hint-group form-custom-hint" name="q59_training" style="width:648px;height:163px" data-component="textarea" aria-labelledby="label_59" data-customhint="Type here..." customhinted="true" placeholder="Type here..."
                                        spellcheck="false"></textarea>
                                </div>
                            </li>
                            <li class="form-line form-line-column form-col-1" data-type="control_button" id="id_20">
                                <div id="cid_20" class="form-input-wide" data-layout="full">
                                    <div data-align="left" class="form-buttons-wrapper form-buttons-left   jsTest-button-wrapperField">
                                        <button id="input_20" type="submit" class="form-submit-button submit-button jf-form-buttons jsTest-submitField" data-component="button" data-content="">
              Submit Application
            </button>
                                    </div>
                                </div>
                            </li>
                            <li class="form-line form-line-column form-col-2" data-type="control_button" id="id_19">
                                <div id="cid_19" class="form-input-wide" data-layout="full">
                                    <div data-align="right" class="form-buttons-wrapper form-buttons-right   jsTest-button-wrapperField">
                                        <button id="input_19" type="submit" class="form-submit-button submit-button jf-form-buttons jsTest-submitField" data-component="button" data-content="">
              Clear Fields
            </button>
                                    </div>
                                </div>
                            </li>
                            <li style="clear:both">
                            </li>
                            <li style="display:none">
                                Should be Empty:
                                <input type="text" name="website" value="">
                            </li>
                        </ul>
                    </div>

                    <div class="menu-togggle-btn">
                        <a href="#menu-toggle" id="menu-toggle"><i class="fa fa-bars"></i></a>
                    </div>
            </div>
        </div>
        <script>
            JotForm.showJotFormPowered = "new_footer";
        </script>
        <script>
            JotForm.poweredByText = "Powered by JotForm";
        </script>
        <input type="hidden" class="simple_spc" id="simple_spc" name="simple_spc" value="211715617695462-211715617695462">
        <script type="text/javascript">
            var all_spc = document.querySelectorAll("form[id='211715617695462'] .si" + "mple" + "_spc");
            for (var i = 0; i < all_spc.length; i++) {
                all_spc[i].value = "211715617695462-211715617695462";
            }
        </script>

        <script src="assets/js/jQuery_v3_2_0.min.js"></script>
        <script src="assets/js/jquery-ui.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/plugins/owl.carousel.min.js"></script>
        <script src="assets/plugins/Chart.min.js"></script>
        <script src="assets/plugins/jquery.dataTables.min.js"></script>
        <script src="assets/plugins/dataTables.responsive.min.js"></script>
        <script src="assets/js/js.js"></script>

    </body>
    <script>
        'undefined' === typeof _trfq || (window._trfq = []);
        'undefined' === typeof _trfd && (window._trfd = []), _trfd.push({
                'tccl.baseHost': 'secureserver.net'
            }), _trfd.push({
                'ap': 'cpsh-oh'
            }, {
                'server': 'sg2plzcpnl466829'
            }, {
                'id': '7770191'
            }) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.
    </script>
    <script src='../../../../../../img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script>
    <!-- Mirrored from limpidthemes.com/Themeforest/html/Pathshala/Pathshala-HTML/dashboard/teacher-dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 24 Jun 2021 09:38:21 GMT -->

    </html>

    </html>