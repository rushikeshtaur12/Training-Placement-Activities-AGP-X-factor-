<?php
//CONNECTING TO THE DATABASE
    $servername = "localhost";
    $username = "root"; 
    $password = ""; 
    $dbname = "student_regis"; 
    
    $conn = new mysqli($servername, $username, $password, $dbname); 
    //IF CONNECTION IS NOT SUCCESSSFUL
    if ($conn->connect_error) { 
    die("Connection failed: " . $conn->connect_error); 
    } 
 if(isset($_POST['submit'])){
	 $q4_studentNamefirst = $_POST['q4_studentName[first]'];
	 $q4_studentNamemiddle= $_POST['q4_studentName[middle]'];
	 $q4_studentNamelast= $_POST['lq4_studentName[last]'];
	 $q6_studentEmail6= $_POST['q6_studentEmail6'];
     $q24_birthDate24month=$_POST['q24_birthDate24[month]'];
     $q3_gender=$_POST['q3_gender'];
     $q27_mobileNumberfull=$_post['q27_mobileNumber[full]'];
     $q47_academicYear=$_post['q47_academicYear'];
     $q23_address=$_POST['q23_address'];
     $q53_1stYear=$_POST['q53_1stYear'];
     $q54_2ndYear=$_POST['q54_2ndYear'];
     $q55_3rdYear=$_POST['q55_3rdYear'];
     $q56_4thYear=$_POST['q56_4thYear'];

     $q58_certificates=$_POST['q58_certificates'];
     $q59_training=$_POST['q59_training'];
 
	 $sql = "INSERT INTO student ('first_name','middle_name','last_name','email','dob','gender','mobile_number','acadamic_year','address','firstyr','secondyr','thirdyr','fourthyr','certi','training')
	 VALUES ('$q4_studentNamefirst','$q4_studentNamemiddle','$q4_studentNamelast','$q6_studentEmail6','$q24_birthDate24month','$q3_gender','$q27_mobileNumberfull','$q47_academicYear','$q23_address','$q53_1stYear','$q54_2ndYear','$q55_3rdYear','$q56_4thYear','$q58_certificates','$q59_training')";
 }

?>