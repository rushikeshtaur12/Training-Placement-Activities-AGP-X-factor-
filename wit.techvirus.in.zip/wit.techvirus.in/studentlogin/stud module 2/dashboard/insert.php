<!DOCTYPE html>
<html>
  
<head>
    <title>Insert Page page</title>
</head>
  
<body>
 <center>
        <?php
  
    $servername = "localhost";
    $username = "root"; 
    $password = ""; 
    $dbname = "student_regis"; 
        $conn = mysqli_connect("localhost", "root", "", "student_regis");
          
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. " 
                . mysqli_connect_error());
        }
		
	 $q4_studentNamefirst = $_REQUEST['q4_studentNamefirst'];
	 $q4_studentNamemiddle= $_REQUEST['q4_studentNamemiddle'];
	 $q4_studentNamelast= $_REQUEST['q4_studentNamelast'];
	 $q6_studentEmail6= $_REQUEST['q6_studentEmail6'];
     $birthday=$_REQUEST['birthday'];
     $q3_gender=$_REQUEST['q3_gender'];
     $q27_mobileNumberfull=$_REQUEST['q27_mobileNumberfull'];
     $q47_academicYear=$_REQUEST['q47_academicYear'];
     $q23_address=$_REQUEST['q23_address'];
     $tenth=$_REQUEST['tenth'];
     $twelvth=$_REQUEST['twelvth'];
     $q53_1stYear=$_REQUEST['q53_1stYear'];
     $q54_2ndYear=$_REQUEST['q54_2ndYear'];
     $q55_3rdYear=$_REQUEST['q55_3rdYear'];
     $q56_4thYear=$_REQUEST['q56_4thYear'];
     $q58_certificates=$_REQUEST['q58_certificates'];
     $q59_training=$_REQUEST['q59_training'];
	 
	 $sql = "INSERT INTO student  VALUES ('$q4_studentNamefirst','$q4_studentNamemiddle','$q4_studentNamelast','$q6_studentEmail6','$birthday','$q3_gender','$q27_mobileNumberfull','$q47_academicYear','$q23_address','$tenth','$twelvth','$q53_1stYear','$q54_2ndYear','$q55_3rdYear','$q56_4thYear','$q58_certificates','$q59_training')";

     if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully." 
                . " Please browse your localhost php my admin" 
                . " to view the updated data</h3>"; 
	 }
	 else{
	 echo "ERROR: Hush! Sorry $sql. " 
                . mysqli_error($conn);
	 }
          
        // Close connection
        mysqli_close($conn);
        ?>




</center>
</body>
  
</html>
          