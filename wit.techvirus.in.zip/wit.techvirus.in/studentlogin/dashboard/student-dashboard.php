<!DOCTYPE html>
<html>
    
<!-- Mirrored from limpidthemes.com/Themeforest/html/Pathshala/Pathshala-HTML/dashboard/student-dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 22 Jun 2021 13:18:32 GMT -->
<head>

        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="">
        <title>AGPIT T&P DASHBOARD</title>

        <!-- Styles -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" media="screen">
		 <link href="assets/css/chartist.min.css" rel="stylesheet" media="screen">
		<link href="assets/css/owl.carousel.min.css" rel="stylesheet" media="screen">
		<link href="assets/css/owl.theme.default.min.css" rel="stylesheet" media="screen">
        <link href="assets/css/style.css" rel="stylesheet" media="screen">

        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
        <link href="assets/fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet" media="screen">

    </head>
    <body>
		<div class="row dashboard-top-nav">
			<div class="col-sm-3 logo">
				<h5><i class="fa fa-book"></i>AGPIT T&P DASHBOARD</h5>
			</div>
	
			<div class="col-sm-5 notification-area">
				<ul class="top-nav-list">

					<li class="user dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<span>STUDENT<span class="caret"></span></span>
						</a>
						<ul class="dropdown-menu notification-list">
						
						
							<li>
								<div class="all-notifications">
									<a href="../logout.php">LOGOUT</a>
								</div>
							</li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
        	
		<div class="parent-wrapper" id="outer-wrapper">
			<!-- SIDE MENU -->
			<div class="sidebar-nav-wrapper" id="sidebar-wrapper">
				<ul class="sidebar-nav">
					<li>
						<a href="student-dashboard.php"><i class="fa fa-home menu-icon"></i> HOME</a>
					</li>
		
					<li class="dropdown">
					<li>
								<a href="form1.php"><i class="fa fa-caret-right"></i>STUDENT DETAILS FORM</a>
							</li>
				    </li>
							
							</li>
						<div class="clearfix"></div>
					
				</ul>
			</div>
			
			<!-- MAIN CONTENT -->
			<div class="main-content" id="content-wrapper">
				<div class="container-fluid">
					<div class="row">
						<div class="col-lg-12 clear-padding-xs">
							<h5 class="page-title"><i class="fa fa-home"></i>HOME</h5>
							<div class="section-divider"></div>
							
						</div>
					</div>
				
					<div class="row">
						<div class="col-lg-12 clear-padding-xs">
							<div class="col-sm-4">
								<div class="my-msg dash-item">
									<h6 class="item-title"><i class="fa fa-address-book-o"></i>MY PROFILE</h6>
									<div class="inner-item">
										<div class="profile-intro">
											
											<div class="col-xs-8 col-sm-12 col-md-8">
												<h5>STUDENT</h5>												
											</div>
											<div class="clearfix"></div>
										</div>
										<div class="profile-details">
											<div class="detail-row">
												
												<div class="col-md-6 col-sm-12 col-xs-6 clear-padding">
													<span>PRN NUMBER</span>
													<p>1234</p>
												</div>
												<div class="clearfix"></div>
											</div>
											<div class="clearfix"></div>
											<div class="detail-row">
												<div class="col-md-6 col-sm-12 col-xs-6 clear-padding">
													<span>ROLL NO</span>
													<p>12</p>
												</div>
												<div class="col-md-6 col-sm-12 col-xs-6 clear-padding">
													<span>DEPARTMENT</span>
													<p>CSE</p>
												</div>
												<div class="clearfix"></div>
											</div>
											<div class="clearfix"></div>											
										</div>
									</div>
								</div>
							</div>								
						</div>
					</div>
				<div class="row">
						<div class="col-md-4">
								<div>
									<?php include('index.php'); ?>
								</div>
							</div>
				</div>
					<div class="row">
						<div class="col-lg-12 clear-padding-xs">
							<div class="col-md-8">
								<div class="my-msg dash-item">
									<h6 class="item-title"><i class="fa fa-bullhorn"></i>ANNOUNCEMENTS</h6>
									<div class="inner-item dashboard-tabs">
										<ul class="nav nav-tabs">
											<li class="active">
												<a  href="#1" data-toggle="tab"><i class="fa fa-graduation-cap"></i><span>TRAININGS</span></a>
											</li>
											<li>								
												<a href="#2" data-toggle="tab"><i class="fa fa-users"></i><span>PLACEMENTS</span></a>
											</li>
											
										</ul>
										<div class="tab-content">
											<div class="tab-pane active" id="1">
												<div class="announcement-item">
													<h5>Guest lecture on fine arts by Smith.<span class="new">New</span></h5>
													
												</div>
												<div class="announcement-item">
													<h5>Guest lecture on fine arts by Smith</h5>
													
												</div>
											</div>
											<div class="tab-pane" id="2">
												<div class="announcement-item">
													<h5>TCS</h5>
												</div>
											</div>
											<div class="tab-pane" id="3">
												<div class="announcement-item">
													<h5>3</h5>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
				<div class="menu-togggle-btn">
					<a href="#menu-toggle" id="menu-toggle"><i class="fa fa-bars"></i></a>
				</div>
				
			</div>
		</div>
	
		<!-- Scripts -->
        <script src="assets/js/jQuery_v3_2_0.min.js"></script>
		<script src="assets/js/jquery-ui.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/plugins/owl.carousel.min.js"></script>
		<script src="assets/plugins/Chart.min.js"></script>
		<script src="assets/plugins/jquery.dataTables.min.js"></script>
		<script src="assets/plugins/dataTables.responsive.min.js"></script>
        <script src="assets/js/js.js"></script>
		
    </body>
</html>